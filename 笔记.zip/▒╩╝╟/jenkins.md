### Jenkins 

Jenkins是一款开源 CI&CD 软件，用于自动化各种任务，包括构建、测试和部署软件。

Jenkins 支持各种运行方式，可通过系统包、Docker 或者通过一个独立的 Java 程序。

可以简单的理解为：一个管理程序，帮你自动打包代码， 运行jar包。 

配合github 的Webhooks能做到自动发包。程序员只需要提交代码 就可以触发发包。

# 搭建：

本文环境： 阿里服务器  centos7

前置： jdk1.8 , maven, git 

直接下载war 包运行即可；不做赘述。

war 包地址：

链接：https://pan.baidu.com/s/1nNsccAVj_85vGWUpWgyWtQ 
提取码：e54u

关于配置：开始默认安装推荐插件 之后其实不用配置什么 使用系统默认的环境变量即可。

关于设置Jenkins中文化 需安装插件Localization：[点我](https://blog.csdn.net/u013053075/article/details/101770152)

  

# 使用jenkins 配合github 自动部署项目

目标：  commit 代码后 jenkins 自动部署项目。

先决条件： 一个git仓库， 一个有公共ip的服务器。

### 第一步 获得github 的 token

![image-20191231155950831](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231155950831.png)

![image-20191231160034852](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231160034852.png)



![image-20191231160107364](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231160107364.png)



![image-20191231160313131](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231160313131.png)

保存后会生产一个 token 字符串，（注： 复制一次后会隐藏）



### 第二步 配置仓库webhooks

先自己准备好的仓库：

里面就一个简单的 hello

![image-20191231160408922](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231160408922.png)



![image-20191231175246725](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231175246725.png)



![image-20191231160628689](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231160628689.png)





![image-20191231160752715](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231160752715.png)





### 第三部配置jenkins:

把之前的token 配上



![image-20191231161314473](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231161314473.png)



填入token （第一步中取得的token） ， 描述随意

![image-20191231161353301](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231161353301.png)







### 开始构建项目



![image-20191231155859611](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231155859611.png)





![image-20191231161638419](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231161638419.png)



![image-20191231161838921](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231161838921.png)



![image-20191231161707177](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231161707177.png)



### 配置自动运行jar 

![image-20191231174843233](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231174843233.png)

一定要加 dontKillme，sh 脚本里就一个简单的运行jar.

![image-20191231174919460](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231174919460.png)



保存， -至此自动构建 配置完成。

项目构建成功后 会在此目录下生成对应文件，



**整个项目： /root/.jenkins/workspace/（你的项目名）**

**jar包 位于： /root/.jenkins/workspace/（你的项目名）/target/**

另：每次重新构建项目时jar程序会被Kill ，替换， 所以不必操心 。



# 测试：

当前：

![image-20191231173845374](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231173845374.png)

前往修改代码并提交仓库：

![image-20191231173944870](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231173944870.png)



![image-20191231174006888](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231174006888.png)



收到消息 自动开始构建。

![image-20191231174018453](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231174018453.png)



**查看结果：**



![image-20191231174434726](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231174434726.png)





# 一些简单的常用命令

### 重启 jenkins

url 端口后加：restart



![image-20191231175129610](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191231175129610.png)

