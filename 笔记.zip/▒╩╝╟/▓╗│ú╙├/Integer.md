Integer比较的问题。

#### Integer 和 Integer 比：

Integer 小于127时是一个常量，大于127时是对象。

所以 用 == 比较的时候 大于127 只会返回 false.

所以直接用 equals来比较即可。

但问题不止于此。

#### Integer 和 别的类型比：

Integer 重写了 equals方法，

![1565229249167](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1565229249167.png)

所有不是 Integer 类型的数据使用 equals比较都会被认作 false.

![2faedcbe0573106f5a35ce069ef859e](C:\Users\mengpeng\AppData\Local\Temp\WeChat Files\2faedcbe0573106f5a35ce069ef859e.png)

所以改为：

![1565229609933](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1565229609933.png)



-128 到127  这之间的数常用率较高。

所以有缓存机制，Integer是对象类型没错，但是不是每次 new 都会创建新对象。

在创建对象之前先从IntegerCache.cache中寻找。如果没找到才使用new新建对象。

