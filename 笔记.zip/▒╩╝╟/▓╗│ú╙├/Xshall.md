![1565232693484](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1565232693484.png)

![1565232834243](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1565232834243.png)

用秘钥文件填充密码。

tail -100f err.log grep | "test"

-n : 上下文相关。

