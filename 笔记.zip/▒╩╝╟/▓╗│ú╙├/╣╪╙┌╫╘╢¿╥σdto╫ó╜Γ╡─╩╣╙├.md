    //手机号
    @Pattern(regexp = "(13\\d|14[579]|15[^4\\D]|17[^49\\D]|18\\d)\\d{8}", message = "sfExpressAccount 格式不正确")



//自定义注解，dto. 验证属性

![1568877121966](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568877121966.png)

