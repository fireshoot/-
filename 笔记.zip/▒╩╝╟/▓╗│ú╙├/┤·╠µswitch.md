![1570518934753](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1570518934753.png)



![1570519207392](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1570519207392.png)



![1570519059010](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1570519059010.png)

![1570519079385](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1570519079385.png)

![1570519092765](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1570519092765.png)

纳入 spring 管理，

通过 map的key 获取不同的 接口实现， 然后执行不同的复写方法。

重构 niu P





