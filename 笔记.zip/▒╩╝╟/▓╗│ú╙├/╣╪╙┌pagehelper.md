#### 分享

分享一下一些工作中遇到的问题，主要是pagehelper 的分页。

#### @pagehelper 分页：

 	pagehelper  实现 的ThreadLocal，在开始分页的时候，将分页的信息绑定到线程A，当要执行查询语句的时候，interceptor拦截器拦截下当前 sql 并将其分解成两条 sql 

1.查询数量，（总数不为0才执行分页sql）

2.拼接分页的sql（查询结果）

查询结果缓存在线程中。

最后在拦截器的finally中移除绑定到线程A中的分页信息。

------------------------------------

### 分页时执行多条sql：

场景： 有一个sql 需要进行分页查询，它的一个字段需要另查询进行拼接。

![](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568788295707.png)

程序报错：

![1568787963464](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568787963464.png)

![1568787940399](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568787940399.png)



第一次分页的分页数据还缓存在线程A 中，线程A 未被杀死，也未清除数据，线程A被复用，第二条sql 在pagehelper 框架下默认也是需要分页的，且分页数据和之前的一致。

一开始我觉得是项目框架注解的是方法体的问题，

然后我测试了 直接使用PageHelper.startPage();

也会报错。

![1568788747024](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568788747024.png) 

![1568788798663](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568788798663.png)

会带来一下两种影响：

####  1.数据缺失。

#### 2.报错，Expected one......



#### 数据缺失:

  	因为被默认分页了

#### 报错:

​	sql1 的结果是缓存在线程A 中的，且线程未被杀死，

sql2 的查询结果也会缓存在sql 中， pagehelper 取值的方式是取线程中缓存的结果， sql2 拿到的结果其实是 sql1 + sql2 的拼接的结果。

所以报错。 





#### 一对多分页的问题： 

1.车辆和司机是一对多关系（迭代三起改为了多对多）；

2.营运状态 的判断逻辑比较复杂。

![1567664337793](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1567664337793.png)



![1567664353189](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1567664353189.png)

营运状态的判断逻辑比较复杂

首先如果有进行中订单判断订单状态，

4-载客 

7/8-接单 

无订单时，判断司机是否开启听单功能，

开-空驶，

不开-停运。

订单还存在拼单的情况，一辆车同一时刻可以有多个不同状态的订单。

询问产品后，产品给出优先级定义 ：载客>接单>空驶>停运



一开始想的比较简单直接就按照之前的项目流程做了。

使用 resultmap  extends 进行一对多查询。

![1567665195226](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1567665195226.png)



![1568020440623](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568020440623.png)



查出对应数据后 在业务层遍历，判断其营运状态，然后一个个 set 再返回给前端。

![1567668172487](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1567668172487.png)

#### 做出来之后发现分页相关，页码，分页后数据数量，均不正确。



检查过后发现

![1567665413532](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1567665413532.png)

### 数据库 由于左连接，一对多。对应的数据条数会补空。



####  度娘：

度娘上给出的 pagehelper一对多分页解决办法：

###### 使用 select 属性 执行子查询

![1568018577442](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568018577442.png)





![1568018611764](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568018611764.png)



鑫哥说使用子查询 又会带来 n+1 问题。

每有一条记录都会执行一次子查询。（n+1）

我有两个一对多关系。

算上分页大概是 50x2+1



然后经过讨论，龙哥提出说可以用in的方式，准备使用 in 的方式进行分页。

### 实现起来大概是这样：

先依据条件查询出 符合分页条件的id . 然后使用 in 的方式获取数据。 

大概实现就是 分成三个sql 。

一个 sql 专门用于计数，

一个sql 负责过滤符合条件的id，

一个sql 用于查询数据，

过滤条件保持一致即可。

###  看起来大概是这样：

![1567667694627](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1567667694627.png)



![1568019083486](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568019083486.png)



![1568019153590](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568019153590.png)



![1568020802433](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568020802433.png)



以下做了一个比较简单的测试 比较 in 方式与 pagehelper 方式的效率问题。

![1568019364972](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568019364972.png)



####  当数据量为 50条时 经过反复测试 得到以下结果：

![1568019456052](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568019456052.png)

![1568019481749](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568019481749.png)



####  当数据了增加到500 时得到以下结果：

![1568019572537](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568019572537.png)

![1568019602648](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568019602648.png)

#### 以上数据均是在本机数据库进行的测试；



随着开发的进行， 又浮现了一个问题：

有一个筛选功能的需求。 依据营运状态分类筛选。

![1568019894567](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1568019894567.png)

之前有说过营运状态不是一个数据库中的字段， 它是由多个字段分情况判断产生的状态。

当下想到的实现功能的办法是：

 拿到所有数据后 在业务层进行判断状态，再进行筛选。

优化一下就是使用流的方式进行过滤。

这样一套下来代码量有点大。很繁琐。



讨论寻求解决方案-。

无果-

最后孟哥给出一个解决方案。

-使用定时器。

数据库 关联表中给出一个字段专门用于存储 营运状态。（operation_state）

写一个定时器 定时维护此字段。

![1567670545738](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1567670545738.png)

由于多对多关系。 优先级关系。

取最小的那个状态即为正确的营运状态。

这样以来所有的过滤操作都可以用sql 完成。



-谢谢。