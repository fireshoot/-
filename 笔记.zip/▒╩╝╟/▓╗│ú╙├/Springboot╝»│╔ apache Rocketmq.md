

### 依赖：

``` u
        <dependency>
            <groupId>org.apache.rocketmq</groupId>
            <artifactId>rocketmq-client</artifactId>
            <version>4.2.0</version>
        </dependency>
```



### Producer1

```
package com.meng.demo.service;

import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import org.apache.rocketmq.common.consumer.ConsumeFromWhere;
import org.apache.rocketmq.common.message.Message;
import org.apache.rocketmq.common.protocol.heartbeat.MessageModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


/**
 * @author meng
 * @create 2019/11/25
 */
@Component
public class Producer1 implements CommandLineRunner {

    @Value("${rocketmq.producer.namesrvAddr}")
    private String metaqNarneserver;

    public void messageListener() {
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer("mengProducer");
        consumer.setNamesrvAddr(metaqNarneserver);
        //consumer.setMessageModel(MessageModel.BROADCASTING);
        try {
            // 订阅PushTopic下 所有Tag的消息
            consumer.subscribe("meng", "*");
            // 程序第一次启动从消息队列头获取数据
            consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);
            //可以修改每次消费消息的数量，默认设置是每次消费一条
            consumer.setConsumeMessageBatchMaxSize(1);
            //在此监听中消费信息，并返回消费的状态信息
            consumer.registerMessageListener((MessageListenerConcurrently) (msgs, context) -> {
            // 会把不同的消息分别放置到不同的队列中
                for (Message msg : msgs) {
                    System.out.println("接收到了消息：" + new String(msg.getBody()));
                }
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            });
            consumer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run(String... args) {
        this.messageListener();
    }

}

```



### ConsumerService



```
package com.meng.demo.service;

import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.common.message.Message;
import org.apache.rocketmq.common.protocol.heartbeat.MessageModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * @author meng
 * @create 2019/11/25
 */
@Service
public class ConsumerService {
    private DefaultMQProducer producer = null;

    @Value("${rocketmq.producer.namesrvAddr}") 
    private String metaqNarneserver;

    @PostConstruct
    public void initMQProducer() {
        producer = new DefaultMQProducer("mengConsumer");
        producer.setNamesrvAddr(metaqNarneserver);

        producer.setRetryTimesWhenSendAsyncFailed(3);
        try {
            producer.start();
        } catch (MQClientException e) {
            e.printStackTrace();
        }
    }

    public void send(String topic, String msg) {
        Message msg2 = new Message(topic, "", "", msg.getBytes());
        try {
            producer.send(msg2);
            return;
        } catch (Exception e) {
            e.printStackTrace();
            return;

        }
    }

    @PreDestroy
    public void shutDownProducer() {
        if (producer != null) {
            producer.shutdown();
        }
    }
}
```



### 坑：

背景：

​		起了五个消费者实例（两个广播模式，三个集群消费模式），生产者起20条消息。

​		两个广播模式20条消息均能收到，三个集群消费模式的消费者 一人只收到了 5条消息。

​		多次测试结果均是丢失消息。（mq是自己搭在虚拟机的。观察可视化界面是有消息的且未被消费）

​		关闭所有实例 重启实例后，  上几次测试积压的消息全部涌向一个消费者被全部消费。

原因：

​		订阅关系一致性， 订阅关系一致指的是同一个消费者 Group ID 下所有 Consumer 实例的处理逻辑必须完全一致。一旦订阅关系不一致，消息消费的逻辑就会混乱，甚至导致消息丢失 。

总结：

​		我在起多个实例的时候，广播模式和集群消费模式的消费者Group 是一样的，所以形成了结果。

​		将集群模式和 广播模式的两类实例 Group  区分开起实例即可。

参考： https://help.aliyun.com/document_detail/43523.html 