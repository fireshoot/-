		AOP是面向切面编程，就是将项目中重复的代码块抽离出来，在一个地方统一实现。比如：日志、事务、数据权限认证等功能。



源代码：

```
package com.haylion.demo.essay.aop;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/**
 * @author meng
 * @create 2019/11/4
 */
@Aspect
@Component
@Slf4j
public class TestAspect {

    //com.kzj.kzj_rabbitmq.controller 包中所有的类的所有方法切面
    //@Pointcut("execution(public * com.kzj.kzj_rabbitmq.controller.*.*(..))")

    //只针对 MessageController 类切面
    //@Pointcut("execution(public * com.haylion.demo.contreoller.MessageController.*(..))")

    //统一切点,对controller及其子包中所有的类的所有方法切面
    @Pointcut("execution(public * com.haylion.demo.contreoller..*.*(..))")
    public void Pointcut() {

    }

    @Before("Pointcut()")
    public void beforeMethod(JoinPoint joinPoint) {
        log.info("调用了前置通知");

    }

    @After("Pointcut()")
    public void afterMethod(JoinPoint joinPoint) {
        log.info("调用了后置通知");
    }

    @AfterReturning(value = "Pointcut()", returning = "result")
    public void afterReturningMethod(JoinPoint joinPoint, Object result) {
        log.info("调用了返回通知");
    }

    @AfterThrowing(value = "Pointcut()", throwing = "e")
    public void afterReturningMethod(JoinPoint joinPoint, Exception e) {
        log.info("调用了异常通知");
    }

    @Around("Pointcut()")
    public Object Around(ProceedingJoinPoint pjp) throws Throwable {
        log.info("around执行方法之前");
        Object object = pjp.proceed();
        log.info("around执行方法之后--返回值：" + object);
        return object;
    }

}

```

### 执行顺序：

![1572838615611](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1572838615611.png)

数据权限: 拿出数据后在切面中根据用户权限 过滤数据。



另一种写法

![image-20200106102050949](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20200106102050949.png)

