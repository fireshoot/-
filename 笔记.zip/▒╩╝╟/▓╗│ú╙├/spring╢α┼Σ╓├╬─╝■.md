```
spring:
  profiles:
    active: test
```

启用哪个配置文件根据 后缀 test 是后缀。

命名格式为

![1565574490465](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1565574490465.png)

PS 使用 .properties  和.yaml 混杂的话好像会出问题 @value拿不到值报错，并没有过多的测试



