

​	https://blog.csdn.net/Woo_home/article/details/103146845 

HashMap 是基于哈希表的 Map 接口是实现的。此实现提供所有可选操作，并允许使用 null 做为值（key）和键（value）。HashMap 不保证映射的顺序，特别是它不保证该顺序恒久不变。此实现假定哈希函数将元素适当的分布在各个桶之间，可作为基本操作（get 和 put）提供稳定的性能。在jdk1.7中的HashMap是基于数组+链表实现的，在jdk1.8中的HashMap是由数组+链表+红黑树实现的。

**实际容量 = 负载因子 x 容量**

![image-20191212162036631](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CHashMap.assets%5Cimage-20191212162036631.png)

```
//默认初始容量-必须为2的幂次方
static final int DEFAULT_INITIAL_CAPACITY = 1 << 4;

//最大容量，如果传入的值大于下面的值，则使用下面定义的值
static final int MAXIMUM_CAPACITY = 1 << 30;

//在构造函数中未指定时使用的负载系数（上面提到的负载因子在这里出现了）
//默认加载因子为0.75（当表容量达到3/4时才会再散列）
static final float DEFAULT_LOAD_FACTOR = 0.75f;

//当链表的长度 >= 8的时候，将链表转换成红黑树
static final int TREEIFY_THRESHOLD = 8;

//在resize()扩容的时候，HashMap的数据存储位置会重新进行计算
//在重新就散存储的位置后，当原有的红黑树数量 <= 6 的时候，则将红黑树转换为链表
static final int UNTREEIFY_THRESHOLD = 6;

//为了避免扩容/调整树化阀值之间的冲突，这个值不能 < 4 * TREEIFY_THRESHOLD
static final int MIN_TREEIFY_CAPACITY = 64;

```



![image-20191212162325111](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CHashMap.assets%5Cimage-20191212162325111.png)



全是容量控制。

tableSizeFor（）方法是为了返回一个你输入的值的最近的的 2次幂数。



为什么容量必须为2的整数幂？
因为获取 key 在数组中对应的下标是通过 key 的哈希值与数组长度 -1 进行与运算，如：i = (n - 1) & hash

1、n 为 2 的整数次幂，这样 n-1 后之前为 1 的位后面全是 1，这样就能保证 (n-1) & hash 后相应的位数既可能是 0 又可能是 1，这取决于 hash 的值，这样能保证散列的均匀，同时与运算效率高

2、如果 n 不是 2 的整数次幂，会造成更多的 hash 冲突（为什么会冲突，稍后会讲解）



取余（%）操作：如果除数是2的幂次方则等价于其除数减一的与操作（&）



1.8 中的hash() 比1.7 中的  ^>> （位移与操作）要少， 应该是引入的红黑树概念不需要散列那么均匀了。减少hash所需要的时间。



1.7

![image-20191213164006987](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CHashMap.assets%5Cimage-20191213164006987.png) 1.8

![image-20191213164016825](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CHashMap.assets%5Cimage-20191213164016825.png)





### hash冲突

开放寻址法： 

​	hash得到的Key 冲突时 自动往下一个找。找到空位再进去。

![image-20191213110929803](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CHashMap.assets%5Cimage-20191213110929803.png)

链表发：

 冲突之后跟后面

![image-20191213110938752](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CHashMap.assets%5Cimage-20191213110938752.png)

当链表大于8 时转为红黑树，

当链表小于6时 又会转为链表，扩容时。



既然HashMap不是线程安全的，那么如何使它成为线程安全的呢？，通过以下代码就可以使HashMap为线程安全的

```java
HashMap<String,Integer> hashMap = new HashMap<String,Integer>();
Map<String, Integer> map = Collections.synchronizedMap(hashMap);
```



transient int size：记录了Map中KV对的个数

loadFactor 装载因子，用来衡量HashMap满的程度。loadFactor的默认值为0.75f（static final float DEFAULT_LOAD_FACTOR = 0.75f;）

int threshold; 临界值，当实际KV个数超过threshold时，HashMap会将容量扩容，threshold＝容量（capacity）*加载因子（loadFactor）

一个重要的概念，容器的容量，capacity：DEFAULT_INITIAL_CAPACITY= 1 << 4; // aka 16



new  一个最基本的 hashmap的基本流程：

装载因子 0.75

hashmap 是非synchronized的所以非常快， hashmap 键值对支持空值



### 取值

get() 方法 会根据键对象的hascode去取值，若此处有多个值 是一个链表或者红黑树则会遍历取值， 通过.eques（）；

使用不可变的 对象昨晚主键时会有更高的 效率 例如 声明了final 的string integer.



所有的对象都是继承于Object类。Ojbect类中有两个方法equals、hashCode，这两个方法都是用来比较两个对象是否相等的。





