git地址：git://github.com/SpringSource/Spring-framework.git

IDEA spring源码编译：https://blog.csdn.net/baomw/article/details/83956300



gradle 添加依赖：

![image-20191209165458684](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CSpring.assets%5Cimage-20191209165458684.png)



DefaultListableBeanFactory：spring工厂 ，产生bean的地方，





# Spring

spring加载ben 的时候所有的bin都是纳入 bendefinition 类里管理。

描述ben的各种信息。 

里面有个map<name,ben>

有个list<name>

循环依赖： A。class  自动注入B B里面又注入A（aoth）

实例化： 整个过程

初始化: 刚new 出来init ?

听得我云里雾里，有点难受。

Aop 的底层是代理，





### @RequestAttribute（“xxx”）

 spring提供的 一套直接从request /session 中获取所需要的值的注解。

获取 request 中缓存的值。

@SessionAttribute
@RequestAttribute

怎么放入 request 中 方法有3

1；@ModelAttribute 注解的方法中 set.

```java
    // 放置attr属性值
    @ModelAttribute
    public Person personModelAttr(HttpServletRequest request) {
        request.setAttribute("myApplicationName", "fsx-application");
        return new Person("非功能方法", 50);
    }
```

2. 拦截器中 set

```java
public class SimpleInterceptor implements HandlerInterceptor {
 
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        request.setAttribute("myApplicationName", "fsx-application");
        return true;
    }
    ...
}
```



3. forward请求转发带过来(不太明晰)

   ```java
   request.setAttribute("myApplicationName", "fsx-application");
   request.getRequestDispatcher("/index").forward(request, response); 
   ```

@RequestAttribute`属性`required`默认为true, `

request.getAttribute`获取不到参数就会抛出异常`ServletRequestBindingException`；

required设置为false，即使没有从request中获取到就忽略跳过，赋值为null; 

