# 关于 RentrantLock

```
jdk1.6 之前synchronized 关键字是一把重量级锁（不论如何都会调用操作系统方法实现的） ReentrantLock 产生于此时，它在串行/单线程时候 java层就能实现锁，性能远远优于synchronized,jdk1.6 sun公司对synchronized进行了大优化，目前这两个锁的性能相差不多。
```

![image-20191206092757010](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191206092757010.png)

首先 ReentrantLock  默认实现非公平锁， 公平锁的创建需要通过这个构造方法的。

![image-20191205145320651](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145320651.png)
**公平锁**：先来后到，线程进入先排队，不是队首不尝试获得锁。	

**非公平锁**：排队，但是，碰巧我刚来，锁开了。我能持有锁。（可以理解为都是排队，非公平可以插队，公平不允许插队） 

**ReentrantLock 的唤醒**： 锁被释放时， 唤醒均是从Node队列中找第二个唤醒（第一个是Null）

**重入锁**：线程可以重复获得锁，不会死锁。

**互斥锁**：一次只能有一个线程进入到临界区；

**读写锁**：

​	在读取数据的时候，可以多个线程同时进入到到临界区(被锁定的区域)

​	在写数据的时候，无论是读线程还是写线程都是互斥的

**自适应自旋锁：**每个线程会自己判断自己需要自旋的次数，若一个线程经常拿到这个锁，那么它自旋的次数会多一些，反之少。经验之谈吧。

**死锁**：获取线程的锁不释放锁，后续线程无法获取送一直处于阻塞。

**RentrantLock 得手动释放锁， 且释放的次数和加锁的次数得一致。否则会死锁。**

IDEA 多线程调试：

![image-20191205145335562](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145335562.png)

### CAS：
CAS是英文单词CompareAndSwap的缩写，中文意思是：比较并替换。CAS需要有3个操作数：内存地址V，旧的预期值A，即将要更新的目标值B。

CAS指令执行时，当且仅当内存地址V的值与预期值A相等时，将内存地址V的值修改为B，否则就什么都不做。整个比较并替换的操作是一个原子操作



# 基本流程概况：

![image-20191205145355005](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145355005.png)



### 测试类：

```
package com.haylion.demo;

import java.util.concurrent.locks.ReentrantLock;

/**
 * @author meng
 * @create 2019/12/4
 */
public class ThreadTest extends Thread {
    static ReentrantLock lock = new ReentrantLock();
    static int i = 0;

    public ThreadTest(String name) {
        super.setName(name);
    }

    @Override
    public void run() {
        System.out.println(System.currentTimeMillis() + " " + this.getName() + "进入run");
        lock.lock();
        try {
            System.out.println("操作A -------------------" + this.getName());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
            System.out.println("已释放锁");
        }
    }

    /**
     * @param args
     * @throws InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {

        ThreadTest test1 = new ThreadTest("thread1");
        ThreadTest test2 = new ThreadTest("thread2");
        ThreadTest test3 = new ThreadTest("thread3");
        test1.start();
        test2.start();
        test3.start();

    }

}
```



## 公平锁 基本流程：

​	最初 第一个线程 ：

![image-20191205145419546](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145419546.png)

![image-20191205145436726](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145436726.png)

拿到当前线程，获取锁的状态， 判断锁是否被人持有 state == 0 。



**未被人持有**：hasQueuedPredecessors() 判断是否需要排队，

![image-20191205145454576](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145454576.png)

临时变量 t  h分别指向  AQS的 首尾，当第一个线程进来时，首尾均为空，

h != t 返回  flase 方法返回。

! hasQueuedPredecessors() 则返回 true 

compareAndSetState（） CAS操作，修改锁的状态值，均成功后执行下一步。

 setExclusiveOwnerThread(current); 设置持有锁线程是当前线程。

整个tryAcquire()方法返回 true , !tryAcquire 返回false. 方法体结束,加锁成功；

![image-20191205145513717](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145513717.png)





### 当第二个线程进入， 且第一个线程未释放锁。

tryAcquire()

![image-20191205145559321](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145559321.png)

执行下一个 if, 判断当前线程是否是持有锁的线程（重入判断），不进入方法体。方法返回false

![image-20191205145610103](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145610103.png)

执行下一个方法acquireQueued(addWaiter(Node.EXCLUSIVE), arg)

addWaiter()

![image-20191205145620190](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145620190.png)

EXCLUSIVE：空的Node队列

Node的组成 ：

![image-20191205145629725](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145629725.png)

// waitStatus ：当前线程的状态： -1 休眠 0 初始 -2 不知 -3  不知

nextWaiter:  不知，代码里是初始化的时候赋予的一个 空的Node，

![image-20191206094024625](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191206094024625.png)



![image-20191205145639474](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145639474.png)

new 了一个 Thread是当前线程的 Node队列。

 因为是第一个线程， 直接进enq()

![image-20191205145648938](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145648938.png)



进入 for （）

第一次进入：

执行compareAndSetHead()，设置AQS的head。

![image-20191205145700233](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145700233.png)

![image-20191205145709856](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145709856.png)

结果如图 顶端未AQS 队列。

AQS的 首尾都指向同一个null Node。

![image-20191205145719419](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145719419.png)

for死循环 ，进入第二次循环： t不为空

结果如下：

![image-20191205145747958](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145747958.png)



return 一个 Node t ；  

![image-20191205145759778](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145759778.png)

addWaiter（）执行完毕返回， 执行 acquireQueued（）方法 

![image-20191205145812528](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145812528.png)

node.predecessor()，返回 P的上一个节点。

![image-20191205145824111](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145824111.png)

![image-20191205145833114](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145833114.png)

 p = head 成立，去尝试获取一遍锁，若获取到了 则是正常流程若没有获取到 则执行

shouldParkAfterFailedAcquire（）检查是否需要 park。

![image-20191205145858106](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145858106.png)

第一次进入shouldParkAfterFailedAcquire（），pred  是P 也就是上一个 Node队列.（值得注意:第一个线程 获取锁后,并未进入队列 。队列的头永远是 一个null Node） 

![image-20191205145908783](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145908783.png)

初始的 waitStatus 是 0 ; 往下

![image-20191205145920329](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145920329.png)



![image-20191205145929897](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145929897.png)

将 上一个Node 的ws(waitStatus ) 改为 -1  ，整个方法结束 return flase。

接着进入 for 循环 再次进入shouldParkAfterFailedAcquire（）

此时 ws 已经变为 -1  方法直接返回 true。前往执行park 让当前线程 park .

![image-20191205145940367](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145940367.png)

线程阻塞 于此。等等被唤醒。

 ws  是上一个Node的状态 而不是 本Node的状态，线程不能设置自身的状态，应该是考虑的park异常的情况。



###  unlock:

![image-20191205145952980](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205145952980.png)

断点 进入的是第一个实现方法。

![image-20191205150001482](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205150001482.png)

c = state - 1 ；（ > 0 重入相关）

if 当前线程不是 AQS的独占线程这抛错，

c == 0  若不等于 0 当为线程持有的不止一把锁，-1 等待 别的锁释放。 当前我测试的是只有一把锁。 所以 c =0 

将AQS独占线程置空， 状态置 0 方法返回 false

![image-20191205150013840](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205150013840.png)

前面说的 waitStatus.

现在进入unparkSuccessor（）

![image-20191205150024542](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205150024542.png)

CAS 修改node中 ws（waitStatus）值为 0 

![image-20191205150036077](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205150036077.png)

这里可以明确的看到 它唤醒的是 head的 next， 而不是 head。

所以应该是这种结构。

![image-20191205150050169](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205150050169.png)

第一个 Node 均为空，说不好是为啥这样设计，再深入看看。todo。

线程被唤醒 unlock 结束，

todo ： 为啥没有看到队列排序的地方？ 





线程从parkAndCheckInterrupt 继续运行

![image-20191205150104356](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205150104356.png)

继续 开始 for 循环。尝试拿锁。----

发现漏了一个 队列规整的方法，若只是唤醒队列还没维护好 下一个线程怎么能拿到锁。 去找了一下 发现在这里。：

![image-20191206103815342](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191206103815342.png)

node 是当前线程的Node  拿到锁后 重新设置AQS的头。setHead 中

![image-20191206104630876](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191206104630876.png)

队列顺序更新 第一个依然是null节点（不是null 是Null节点）。  





# 非公平锁

![image-20191205150201725](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CReentrantLock.assets%5Cimage-20191205150201725.png)

与公平锁不同， 非公平锁一进来就尝试修改 锁状态。

后面的和公平锁一样。

唤醒和公平锁一样 从Node队列中唤醒。 







美团技术团队分享的ReentrantLock:[文章](https://mp.weixin.qq.com/s?__biz=MjM5NjQ5MTI5OA==&mid=2651751125&idx=1&sn=7933de969a1bc43009c1453250ebb2bb&chksm=bd125b988a65d28e321ba09ff1c18adbcdf8fa394a981f839fe696a7a9658b44a5b48a5f41f0&mpshare=1&scene=1&srcid=12050TgdtoQflVGqvIjFyJNa&sharer_sharetime=1575547738063&sharer_shareid=6f28fe4d30bd7c056229a67d8ecc9bfe&key=cb3be85a557319fcd796e88fb0306c80a7c8b3afb5786feafbbc346474fdce7703cbbf79df91391d5588aa9ffcce4a5f79062b8018e1318b96ddbc4858a49c0651c7bba669c55f200e7e64b7d01e4423&ascene=1&uin=MjYxOTUwNDAzMw%3D%3D&devicetype=Windows+10&version=62070158&lang=zh_CN&exportkey=AyLoCrUKeFSUifXkoFgdkzM%3D&pass_ticket=kQMWf9YFzdghuICT8RM0qbZ9bzF%2F8cj2b1py0fjpaetSpyQhlV588Ahgy8Xb7X0W)





## 自旋锁

锁竞争是kernal mode下的，会经过user mode(用户态)到kernal mode(内核态) 的**切换**，是比较花时间的。

**自旋锁**出现的原因是人们发现大多数时候**锁的占用只会持续很短的时间**，甚至低于切换到kernal mode所花的时间，所以在进入kernal mode前让线程等待有限的时间，如果在此时间内能够获取到锁就**避免了很多无谓的时间**，若不能则再进入kernal mode竞争锁。

在JDK 1.6中引入了自适应的自旋锁，说明**自旋的时间不固定，要不要自旋变得越来越聪明**。

自旋锁在JDK1.4.2中就已经引入，只不过默认是关闭的，可以使用`-XX：+UseSpinning`参数来开启，在JDK1.6中就已经改为**默认**开启了。



## 锁消除

如果JVM明显检测到某段代码是**线程安全**的(言外之意：无锁也是安全的)，JVM会安全地原有的锁消除掉！



## 锁粗化

默认情况下，总是推荐将**同步块的作用范围限制得尽量小**。

但是如果一系列的连续操作都对**同一个对象反复加锁和解锁**，甚至加锁操作是出现在循环体中的，频繁地进行互斥同步操作也会导致**不必要的性能损耗**。

JVM会将加锁的范围**扩展**(粗化)，这就叫做锁粗化。



## 轻量级锁

轻量级锁能提升程序同步性能的依据是**“对于绝大部分的锁，在整个同步周期内都是不存在竞争的”**，这是一个经验数据。

- 如果没有竞争，轻量级锁使用**CAS操作避免了使用互斥量的开销**
- 但如果存在锁竞争，除了互斥量的开销外，还额外发生了CAS操作，因此在有竞争的情况下，轻量级锁会比传统的重量级锁更慢。

简单来说：如果发现同步周期内都是**不存在竞争**，JVM会使用**CAS操作来替代操作系统互斥量**。这个优化就被叫做轻量级锁。

 ##### 互斥量： 

操作系统中同一时刻 保证只有一个线程能占用。



## 偏向锁

偏向锁就是在**无竞争的情况下把整个同步都消除掉，连CAS操作都不做了**！