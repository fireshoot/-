# mybatis





# 配置项：

```
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration PUBLIC "-//mybatis.org//DTD Config 3.0//EN" "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
    <settings>
        <!--驼峰转换-->
        <setting name="mapUnderscoreToCamelCase" value="true"/>
        <!--开启日志输出-->
        <setting name="logImpl" value="STDOUT_LOGGING" />
    </settings>
    <typeAliases>
        <typeAlias alias="Integer" type="java.lang.Integer"/>
        <typeAlias alias="Long" type="java.lang.Long"/>
        <typeAlias alias="HashMap" type="java.util.HashMap"/>
        <typeAlias alias="LinkedHashMap" type="java.util.LinkedHashMap"/>
        <typeAlias alias="List" type="java.util.List"/>
        <typeAlias alias="ArrayList" type="java.util.ArrayList"/>
        <typeAlias alias="LinkedList" type="java.util.LinkedList"/>
    </typeAliases>
</configuration>
```



### 缓存：

**一级缓存：**

  每执行一条sql mybatis都会对其进行缓存，查询时若sql一致 则直接从缓存中取数据，

commit 会清除一级缓存。

一级缓存只存在一次会话中，

二级缓存是全局缓存。



不太行， 设计有缺陷，

在分布式环境下会出问题，

还是建议使用redis 之类的来做缓存处理。

-美团技术团队