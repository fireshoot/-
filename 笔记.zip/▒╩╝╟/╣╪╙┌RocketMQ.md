

# rocketMQ :

![1574836668961](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1574836668961.png)

rocketMQ安装参考： https://blog.csdn.net/wangmx1993328/article/details/81536168 

### 注意： 

1.卸载openjdk

2.就算环境变量设置对了 也得在要运行的.sh 文件中 添加

JAVA_HOME 路径。（所有要启动.sh均要添加）

export JAVA_HOME=/home/jdk1.8.0_231 （根据自己实际路径）
export CLASSPATH=$JAVA_HOME/lib:$JAVA_HOME/jre/lib

![1574753818163](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1574753818163.png)

使用nohup sh bin/mqnamesrv & 

### ignoring input and appending output to 'nohup.out'  

不用管。  

### tail -f ~/logs/rocketLogs/broker.log 出现找不到该文件，

需要修改JVM的配置： 

runserver.sh 将原来的4G改小。

![1574753982662](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1574753982662.png)

 runbroker.sh将原来的8G改小 。

![1574754014462](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1574754014462.png)



mq可视化工程：

![1574754294068](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1574754294068.png)

![1574755331191](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1574755331191.png)

 

参考：https://blog.csdn.net/lwf006164/article/details/91628252 



查看本机ip地址： ifconfig



本机mq安装地址：

/home/rocketmq-all-4.3.0/distribution/target/apache-rocketmq/bin

可视化工具地址：

/home/rocketmq-console/target

 http://192.168.9.145:8080/#/ 



### 开启服务：

```
# 启动命令,并且常驻内存
$ nohup sh mqnamesrv &
# 查看启动日志能看到：The Name Server boot success字样则成功
$ tail -f ~/logs/rocketmqlogs/namesrv.log

# 启动命令，并且常驻内存:注意ip地址要配置成为服务的ip地址，保证地址以及端口能够访问
> nohup sh mqbroker -n localhost:9876 &
 
# 查看启动日志
> tail -f ~/logs/rocketmqlogs/broker.log

#启动可视化插件工程jar包
java -jar xxx.jar &

#发送消息
> export NAMESRV_ADDR=localhost:9876
 > sh bin/tools.sh org.apache.rocketmq.example.quickstart.Producer
 
#接收消息
sh bin/tools.sh org.apache.rocketmq.example.quickstart.Consumer
```

### 关闭服务：

 打开的时候，先NameServer再是Broker。关闭就是先Broker在NameServer。 

```
> sh mqshutdown broker

> sh mqshutdown namesrv
```

### 其他：

```
查看集群情况： ./mqadmin clusterList -n 127.0.0.1:9876
查看 broker 状态： ./mqadmin brokerStatus -n 127.0.0.1:9876 -b 172.20.1.138:10911
查看 topic 列表： ./mqadmin topicList -n 127.0.0.1:9876
查看 topic 状态： ./mqadmin topicStatus -n 127.0.0.1:9876 -t MyTopic (换成想查询的 topic)
查看 topic 路由： ./mqadmin topicRoute -n 127.0.0.1:9876 -t MyTopic
```



每次开启都得去一遍指定目录，可以配置个小脚本一键运行mq：

![1574754494738](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1574754494738.png)

关闭同理；



Producer：发信者， 

Consumer :收信者， 

Broker :暂存 ,

NameServer :传输 ,

本机mq服务器地址：192.168.9.145

本机ip4地址 ：192.168.8.135



### mqadmin 

rocketmq自带的命令行工具  mqadmin 

 https://www.jianshu.com/p/84a6948f45cf 

可以做很多事情 例如操作topic ----

查看已有topic：

```undefined
bin/mqadmin topicList -n localhost:9876
```

topic 创建:

```
bin/ mqadmin updateTopic -b 192.168.9.145:10911 -n 192.168.9.145:9876 -t meng
```

坑：这个命令不能直接去到/bin目录下 执行：

```
mqadmin updateTopic -b 192.168.9.145:10911 -n 192.168.9.145:9876 -t meng
```

需要在/bin目录上 运行 

```
bin/ mqadmin updateTopic -b 192.168.9.145:10911 -n 192.168.9.145:9876 -t meng
```



#  测试：

加入依赖：

```
        <dependency>
            <groupId>org.apache.rocketmq</groupId>
            <artifactId>rocketmq-client</artifactId>
            <version>4.3.0</version>
        </dependency>
```





```
package com.meng.rocketmq.mq;

import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.consumer.MessageSelector;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import org.apache.rocketmq.client.consumer.listener.ConsumeOrderlyContext;
import org.apache.rocketmq.client.consumer.listener.ConsumeOrderlyStatus;
import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import org.apache.rocketmq.client.consumer.listener.MessageListenerOrderly;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.common.consumer.ConsumeFromWhere;
import org.apache.rocketmq.common.message.MessageExt;

import java.util.List;

/**
 * @author meng
 * @create 2019/11/13
 */
public class GetMsg {
    public static void main(String[] args) throws MQClientException {
        BaseGetMQ();
        //Test();
    }


    public static void BaseGetMQ() throws MQClientException {

        DefaultMQPushConsumer defaultMQPushConsumer = new DefaultMQPushConsumer("MengPeng");
        defaultMQPushConsumer.setNamesrvAddr("192.168.9.145:9876");
                
       // 程序第一次启动从消息队列头获取数据
defaultMQPushConsumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);
        // 订阅meng下 所有Tag的消息
        defaultMQPushConsumer.subscribe("meng", "*");
        defaultMQPushConsumer.registerMessageListener(new MessageListenerOrderly() {

            @Override
            public ConsumeOrderlyStatus consumeMessage(List<MessageExt> list, ConsumeOrderlyContext consumeOrderlyContext) {
                //System.out.printf(Thread.currentThread().getName() + "Receive New Messages:" + list + "%n");
                MessageExt messageExt = list.get(0);
                System.out.println("mess: " + new String(messageExt.getBody()));
                return ConsumeOrderlyStatus.SUCCESS;
            }
        });

        defaultMQPushConsumer.start();
        System.out.println("----开始接收消息----");
    }

}
```



```
package com.meng.rocketmq.mq;

import org.apache.rocketmq.client.exception.MQBrokerException;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.client.producer.MessageQueueSelector;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.common.message.Message;
import org.apache.rocketmq.common.message.MessageQueue;
import org.apache.rocketmq.remoting.common.RemotingHelper;
import org.apache.rocketmq.remoting.exception.RemotingException;

import java.io.UnsupportedEncodingException;
import java.util.List;

/**
 * @author meng
 * @create 2019/11/13
 */
public class SendMsg {

    public static void main(String[] args) throws MQClientException, UnsupportedEncodingException, RemotingException, InterruptedException, MQBrokerException {
        baseMq();
    }


    /**
     * 普通发消息
     *
     * @throws MQClientException
     * @throws RemotingException
     * @throws InterruptedException
     * @throws MQBrokerException
     * @throws UnsupportedEncodingException
     */
    public static void baseMq() throws MQClientException, RemotingException, InterruptedException, MQBrokerException, UnsupportedEncodingException {
        //初始化。
        DefaultMQProducer producer = new DefaultMQProducer("MengPeng");
        // mq地址。
        producer.setNamesrvAddr("192.168.9.145:9876");
        //启动
        producer.start();
        for (int i = 0; i < 20; i++) {
            Message msg = new Message("meng", " TagA", (" Hello RocketMQ " + i).getBytes(RemotingHelper.DEFAULT_CHARSET));
            msg.putUserProperty("a", String.valueOf(i));
            msg.putUserProperty("b", "hello");
            SendResult sendResult = producer.send(msg);
            System.out.println(sendResult);
        }
        producer.shutdown();
    }
}
```



![1574755065080](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1574755065080.png)





# -

MQ收消息是：多线程，乱序。

磁盘的顺序写入速度是 600mb/s

乱序写入是100k/s





需要顺序读取消息的场景：  增 -> 删

若不是顺序读取会变成 删->增。

顺序发送消息给专门的队列，专门的队列只读取顺序消息。两端配合。

若都采用都采用顺序读消息效率会很低。



问题集:

修改.conf 企图修改配置项，但是修改后还是失败。





起多个消费者：

 ： https://help.aliyun.com/document_detail/43523.html 

订阅关系一致，起消费者的时候消费者不同类型的话 当有不同的group， 否者会出现消息阻塞的情况。



### 重复消费消息：

 ![image-20191206144130554](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5C%E5%85%B3%E4%BA%8ERocketMQ.assets%5Cimage-20191206144130554.png)消息可以被很多消费者订阅， 其中一个消费者消费失败了，会申请重发， 服务器重发消息会被收到过一次消息的消费者再收到一次消息。

### 幂等校验：

同样的参数调用我这个接口，调用多少次结果都是一个

强校验：磁盘持久化校验

弱校验：缓存校验



docker 直接拉镜像安装mq

太香了 直接装上不讲道理。 什么环境变量，统统无视。早配好了。 

https://blog.csdn.net/fenglibing/article/details/92378090