1.首先git 上申请一个自己的仓库，并映射到笔记所在的文件夹

1）：申请一个git 账号（这一步我就不搞了），创建一个仓库。

![image-20191211120350254](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CTypora%E4%BA%91%E7%AC%94%E8%AE%B0.assets%5Cimage-20191211120350254.png)

![image-20191211120615033](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CTypora%E4%BA%91%E7%AC%94%E8%AE%B0.assets%5Cimage-20191211120615033.png)

2） 复制 https/ssh  clone 到你指定位置:

![image-20191211122151931](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CTypora%E4%BA%91%E7%AC%94%E8%AE%B0.assets%5Cimage-20191211122151931.png)

产生了 仓库名的文件夹：

![image-20191211122203997](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CTypora%E4%BA%91%E7%AC%94%E8%AE%B0.assets%5Cimage-20191211122203997.png)

2.偏好设置中设置 图片生成时 复制图片到当前文件夹位置。

![image-20191211115713582](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CTypora%E4%BA%91%E7%AC%94%E8%AE%B0.assets%5Cimage-20191211115713582.png)



然后随便写个笔记， 拖入图片即会在当前笔记位置生产文件夹，且会保存图片。

![image-20191211122811661](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CTypora%E4%BA%91%E7%AC%94%E8%AE%B0.assets%5Cimage-20191211122811661.png)





以后都在这个xxx 项目文件夹下写笔记。之后每次写完打开git上传 即可。（不过在gIt 依然是看不到的，拉取下来是可以看的，不影响） 

![image-20191211123019524](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CTypora%E4%BA%91%E7%AC%94%E8%AE%B0.assets%5Cimage-20191211123019524.png)



git:

![image-20191211123602354](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CTypora%E4%BA%91%E7%AC%94%E8%AE%B0.assets%5Cimage-20191211123602354.png)

![image-20191211123626581](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5CTypora%E4%BA%91%E7%AC%94%E8%AE%B0.assets%5Cimage-20191211123626581.png)