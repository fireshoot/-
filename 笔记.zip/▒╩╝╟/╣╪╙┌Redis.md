# redis ：

![1573698986134](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5C1573698986134.png)

切换db ：select

查看所有key: keys * 

​	*是通配符 指所有

​	其实可以改为关键字符起到搜索的作用。![image-20191223173126512](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191223173126512.png)

scan 也是遍历键：

 scan <起点> <模式匹配？> <长度，默认10>



查看某key :get keyname

设置了密码 在命令行需登录： auth "password"

检查某键过期时间: ttl

incr : 自增

move key db ： 本地db间的key转移



迁移指定key:

dump key 

restore key ttl "xxxxx" 将此序列化结果转化为 key 



 migrate 127.0.0.1 6379 hello 0 1000





redis  是单线程的，采用I/O多路复用。

Redis 有一个本地方法栈， 同一时刻只会有一条命令执行。



string 可以存很多东西， 甚至是二进制。 但是有大小限制 512 MB



setnx   同一时刻只有一个客户端能设置成功, 可以用作分布式锁的一种实现。http://redis.io/topics/distlock。

![image-20191223143601679](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191223143601679.png)

### hash:

基础命令：  hset  《变量名》 《键名》 《值》

​			![image-20191230104505045](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191230104505045.png)

 Redis 中的hash很神奇，暂时没看明白先记着。

hset key field value

这个 field 相当于key 。 可以通过 hget key field  获取 value 

![image-20191223145305392](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191223145305392.png)

![image-20191223145516820](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191223145516820.png)



当field个数比较少且没有大的value时，内部编码为ziplist：

当有value大于64字节，内部编码会由ziplist变为hashtable：

当field个数超过512，内部编码也会由ziplist变为hashtable：



就像个map  user 是变量名

​	此类型数据存储在redis 可以用序列化 的方式存储。

​	

应用场景：

​	共享session，分布式服务器吧session放到同一个redis。

​	过期时间。

​	

![image-20191223155247961](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191223155247961.png)



### 列表： list 

基础命令： rpush 《key》《v1 v2 v3 c4》

![image-20191230104517293](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191230104517293.png)

 有序的 双端链表， 可以从前或者后 插入push / 弹出 pop

还可以通过下表获取，

在指定位置插入。

ziplist（压缩列表）：当列表的元素个数小于list-max-ziplist-entries配置 （默认512个），同时列表中每个元素的值都小于list-max-ziplist-value配置时 （默认64字节），Redis会选用ziplist来作为列表的内部实现来减少内存的使 用



### 集合 set

基本语法： sadd 《key》 《v1 v2 v3》

![image-20191230104637613](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191230104637613.png)

无序， 不重复。

能 取交，并，差集

·intset（整数集合）：当集合中的元素都是整数且元素个数小于set-maxintset-entries配置（默认512个）时，Redis会选用intset来作为集合的内部实 现，从而减少内存的使用。 ·hashtable（哈希表）：当集合类型无法满足intset的条件时，Redis会使 用hashtable作为集合的内部实现。



### 有序集合 sortSet

基础语法： zadd 《key》 《score值 根据这个排序》《v》 

![image-20191230105135271](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191230105135271.png)

​		

它和列表使用索引下标作为 排序依据不同的是，它给每个元素设置一个分数（score）作为排序的依 据

​		·ziplist（压缩列表）：当有序集合的元素个数小于zset-max-ziplistentries配置（默认128个），同时每个元素的值都小于zset-max-ziplist-value配 置（默认64字节）时，Redis会用ziplist来作为有序集合的内部实现，ziplist 可以有效减少内存的使用。 ·skiplist（跳跃表）：当ziplist条件不满足时，有序集合会使用skiplist作 为内部实现，因为此时ziplist的读写效率会下降。



### Bitmaps

可以理解为以位为单位的数组，它其实并不是一种新的数据结构，其实就是字符串，只是含义不是简单的字符串。 能合理的操作位 能极大地提高开发效率和内存使用率。布隆过滤器就是用它实现的，

布隆过滤器：检索一个元素是否在一个集合中。它的优点是**空间效率和查询时间都远远超过一般的算法**，缺点是**有一定的误识别率和删除元素困难**。

一般的布隆过滤器会提供两个方法：**Test** 和 **Add**

**Test**用来确认某个元素是否在集合内。如果它返回：

1. false，那么这个元素**一定不在**集合内。
2. true，那么这个元素只是**有可能**在集合里面，部分不在集合内的元素会被误判在集合内，布隆过滤器的假正率（False positive rate）用来描述这一概率，其**随着数据的增大而增大**，同时也**和所使用的hash函数有关**。

**布隆过滤器原理**

布隆过滤器的原理是，当一个元素被加入集合时，通过K个hash函数将这个元素映射成一个位数组中的K个点，把它们置为1。检索时，我们只要看看这些点是不是都是1就（大约）知道集合中有没有它了：如果这些点有任何一个0，则被检元素一定不在；如果都是1，则被检元素很可能在。



### HyperLogLog

本质是一种算法。不算是数据类型。

可以利用极小的内存空间完成独立总数统计

节省的内存惊人， 

![image-20191225165614844](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191225165614844.png)

但是不是100% 正确， 官方给出的错误率是0.81%



### GEO

地理信息定位功能，

底层是Sortset

是作者借鉴ardb数据库实现的，（国产哟）

内部提供了诸多计算距离等方法，可以直接使用

没有删减，但是底层是zset 不会重复。可以用zrem 实现删除



### 事务：

开启事务：multi:

结束事务： exec

redis的事务比较简单， 不支持回滚， 其实就是把事务中包含的命令放入一个队列，执行。

![image-20191227094503488](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191227094503488.png)

![image-20191227094515706](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191227094515706.png)

​		在redis中，对于一个存在问题的命令，如果在入队的时候就已经出错，整个事务内的命令将都不会被执行（其后续的命令依然可以入队），如果这个错误命令在入队的时候并没有报错，而是在执行的时候出错了，那么redis默认跳过这个命令执行后续命令。也就是说，redis只实现了部分事务。

总结redis事务的三条性质：

1. 单独的隔离操作：事务中的所有命令会被序列化、按顺序执行，在执行的过程中不会被其他客户端发送来的命令打断
2. 没有隔离级别的概念：队列中的命令在事务没有被提交之前不会被实际执行
3. 不保证原子性：redis中的一个事务中如果存在命令执行失败，那么其他命令依然会被执行，没有回滚机制





## 不推荐多环境同时使用同一个redis 的不同db

因为 Redis 本质上是单线程 操作，如果一条查询语句很慢，会影响多个db，



Redis 有一个慢查询日志。 超过配置文件中slowlog-log-slower-than预设的阈值会被记录在日志中 便于查看。

使用命令 showlog get -n   n表示条数。



redis 的订阅/发布  不会做持久化， 所以订阅者并不会收到之前的消息。

![image-20191225172018672](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191225172018672.png)

![image-20191225172110090](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191225172110090.png)



### 持久化：

  RDB / AOF

RDB：把当前数据生成内存快照保存到磁盘，文件压缩比高，恢复快，

缺点：定时备份，没办法做到秒级，一般作为数据类型冷备，和数据传输

AOF：以日志形式，记录每条命令（文本形式）到缓冲区，然后从缓冲区备份到硬盘，之后可以硬盘数据通过日志恢复数据， 不会缺失数据。

缺点：由于是命令行形式，需要不断的追加，文件会越来越大，所以需要定期执行重写操作来降低文件体积。





redis重启是优先加载aof 恢复数据的



### 阻塞：

​	Redis 是单线程的 阻塞对Redis 的英雄非常巨大，阻塞产生的原因有很多 大致可以分为两种 --我感觉没有必要写这些 略过。

大致就是说要在代码里加日志， 要查看Redis的慢查询日志，通过这些判别Redis 到底是为什么阻塞，

​	1.慢查询语句优化， 禁用keys sort 之类的语句（slowlog get [n] ，获取慢查询日志 可通过配置文件配置慢查询阈值）

​	2.对那些操作很多数据的，拆解成小个的对象。（redis-cli-h{ip}- p{port}bigkeys。获取大对象有哪些）

​	3.CPU饱和，单个redis吧cpu跑满了

​	4.开启了持久化，持久化引起阻塞

.... 还有很多



### 内存：

Redis进程内消耗主要包括：自身内存+对象内存+缓冲内存+内存碎片，

空的redis的自身内存大概在3mb

对象内存就是 各种键值对的内存。

缓冲内存：客户端缓冲（所有接入redis的TCP输入输出缓冲） + 复制积压缓冲 + AOP缓冲



redis  默认无限使用内存 建议配置内存最大值、

**惰性删除：**

redis 的键并不会到期就删除, 而是在你读取这个键时 若redis发现这个键过期了 将删除它 并返回空。

**定时删除任务：**

![image-20191230111250407](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191230111250407.png)

![image-20191230111342137](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191230111342137.png)





todo 理解内存：





### 布隆过滤器：

 高效的，不保证完全正确的，快速判别数据是否存在的一种算法；其底层是一个bit 向量。

![image-20200106110423536](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20200106110423536.png)

实现原理： 此数据经过k此hash() 得到的k个hashcode 存入bit数组中，1标识有数据 0 标识无，

下次要判某数据是否存在，则使用数据 n  经k 次hash() 获得K个hashcode  查看K 处位置是否均为1,   若各处均为1 则数据可能存在， 任何一处为0数据必然不存在。 

删除困难几乎是不可能的，

概率由你定义的hash（）个数和 bit 长度决定，需要注意。

概率公式为：

![image-20200106111854605](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20200106111854605.png)







### redis 并发锁：

​	目前的理解： redis是单线程的 所以可以用它来实现并发锁，setnx （setIfAbsent ）

```
//设置锁
if (cacheService.setIfAbsent(key, timeoutTimeMilli, timeoutSecond, TimeUnit.SECONDS)) {    logger.info("Thread：" + Thread.currentThread().getName() + " lock success");    return timeoutTimeMilli;}
//延迟一定毫秒，防止请求太频繁try {    Thread.sleep(LOOP_WAIT_TIME_MILLISECOND);} catch (InterruptedException e) {    logger.error("DistributedLock lock sleep error", e);    Thread.currentThread().interrupt();}
```

释放锁 直接删掉这个健即可。