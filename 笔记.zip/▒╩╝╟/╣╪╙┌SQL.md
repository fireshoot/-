		表中存储的是完整记录，一般有两种组织形式：堆表(所有的记录无序存储)，或者是聚簇索引表(所有的记录，按照记录主键进行排序存储)。索引中存储的是完整记录的一个子集，用于加速记录的查询速度，索引的组织形式，一般均为B+树结构。

mysql中可以使用explain关键字来查看sql语句的执行计划。

# in

###  sql执行时会抛出ORA-01795异常 

where in （x） 超过 1000 条。

用 exists  / not in  优化sql 中 in 超过一千条时会提示错误， 且效率不高。

可以使用   EXISTS 代替  in 。

可以使用  NOT EXISTS 代替 not in 以优化 ![1573458930185](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1573458930185.png)



### sql中round(),floor(),ceiling()函数的用法和区别

​	round() 遵循四舍五入把原值转化为指定小数位数，

​	如：round(1.45,0) = 1;round(1.55,0)=2

​	floor()向下舍入为指定小数位数 如：floor(1.45,0)= 1;floor(1.55,0) = 1

​	ceiling()向上舍入为指定小数位数 如：ceiling(1.45,0) = 2;ceiling(1.55,0)=2

​	date ： 取时间格式中的 年月日 



### MySQL server has gone away 

**方式1（修改MySQL配置文件）：**

找到mysql目录下的my.ini配置文件，加入以下代码：

max_allowed_packet=500M

wait_timeout=288000

interactive_timeout = 288000

 MySQL server has gone away   wait_timeout 设置大一些



**offset**：

和limit 连用，

limit x, y  从第x条开始 取y 条

limit x offset y 从第y 条开始去x 条





### 异或？？？？？？？？？？？？

select b.id,a.student 

from seat as a,seat as b,

(select count(*) as cnt from seat) as c 

where b.id=1^(a.id-1)+1 || (c.cnt%2 && b.id=c.cnt && a.id=c.cnt);

todo 待学

### explain命令

![image-20191226154554528](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5Cimg%5Cimage-20191226154554528.png)

**id** ： 执行顺序 当有子查询时会有多行，id 越大越先被执行。

**select_type**:		查询类型， 

- SIMPLLE：简单查询，该查询不包含 UNION 或子查询
- PRIMARY：如果查询包含UNION 或子查询，则**最外层的查询**被标识为PRIMARY
- SUBQUERY：子查询中的第一个select语句(该子查询不在from子句中)
- DERIVED：包含在from子句中子查询(也称为派生表)

**table**:	 操作的表

**possible_keys**: 	可用的索引

**key**: 	实际使用的索引

**key_len**:	索引里使用的字节数

...

[抄自3y](https://mp.weixin.qq.com/s?__biz=MzI4Njg5MDA5NA==&mid=2247484461&idx=2&sn=5469534e2f370aba86c3a24a2ff52b70&chksm=ebd7452cdca0cc3ad456d695a78f48e72c245f85b4afb210fb7b62218e89785d964d72ec4891&token=620000779&lang=zh_CN&scene=21###wechat_redirect)







# 坑

开发过程中  前端传递的时间值一般是只包含到秒，然而临界时间如23:59:59:001s  这一秒钟内的数据 若是不精确到毫秒是无法查询出来的， 



###  sql执行时会抛出ORA-01795异常 

where in （x） 超过 1000 条。

用 exists  / not in  优化

​	count(1)、count()与count(列名)的执行区别*

*count(*)包括了所有的列，相当于行数，在统计结果的时候，不会忽略列值为NULL  

count(1)包括了忽略所有列，用1代表代码行，在统计结果的时候，不会忽略列值为NULL  
count(列名)只包括列名那一列，在统计结果的时候，会忽略列值为空（这里的空不是只空字符串或者0，而是表示null）的计数，即某个字段值为NULL时，不统计。

count(主键)> count(1) > count(*)  [一般情况下]

考虑索引，最好不要用count(1) ，