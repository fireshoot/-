https://www.cnblogs.com/swda/p/12013439.html

本机路径：/home/redis4.0.6 redis-service



#### 配置redis.conf

　　1.进入配置文件 vim redis.conf

　　2.注释掉绑定ip bind 127.0.0.1  #不注释的话就是默认只允许本地访问

　　3.将保护模式改成no daemonize yes  设置为no

设置密码才能远端连接。

1.127.0.0.1:6379> config get requirepass

127.0.0.1:6379> config set requirepass dyydyy //密码是dyydyy



Redis 3.0 起开始支持分布式。



