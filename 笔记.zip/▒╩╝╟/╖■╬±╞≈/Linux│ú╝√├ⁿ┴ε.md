xshll

 -tail -f -n (倒数开始多少行)  xx.log

查看日志信息

也可以写成 

 -tail -(倒数开始多少行)f  xx.log



### 可执行权限

 chmod +x <文件名> 

### 创建文件夹

mkdir xxx

### 删除

rm -rf xxx

### 重命名

mv xx xxx2

### 解压

tar -xzvf xxx

### 挂起也不结束

nohup 





### 进程

所有：ps aux 

搜索：ps -ef | grep xx

杀死: kill -s 9 <pid>



# 防火墙

##### 开放端口

firewall-cmd --permanent --zone=public --add-port=3306/tcp

##### 开/关防火墙

systemctl start firewalld / systemctl stop firewalld

##### 查看防火墙状态

systemctl status firewalld

##### 已开放端口

firewall-cmd --list-ports

##### 重启：

firewall-cmd --reload 

# 端口状态

netstat -anp | grep xx





# 卸载

##### Centos7完全卸载mysql

第一步，查看mysql相关软件包：

###### rpm -qa | grep -i mysql



# 系统版本

cat /etc/redhat-release



​        	               

# vim

: q!  退出不保存  

：/关键字 搜索

：wq 保存退出







查找目录：find /（查找范围） -name '查找关键字' -type d
查找文件：find /（查找范围） -name 查找关键字 -print

 

# 查看应用安装目录

whereis  《xxx》