[抄自 java3y](https://mp.weixin.qq.com/s?__biz=MzI4Njg5MDA5NA==&mid=2247484631&idx=1&sn=ffca3c18cce7392ef96dce268cd7d6df&chksm=ebd745d6dca0ccc0964a4c99afaa030c997ee75379e14b5d7fc0beacc4c59f33318af266a7ce###rd)   

```
cat /etc/redhat-release
// 结果CentOS Linux release 7.3.1611 (Core)
```



# 常用命令

启动容器：  docker start id/名

重启： docker restart id/名

停止：docker stop id/名

强制停止容器： docker kill id/名



##### 列出本地容器

docker images 

-a 列出所有

-q 只要Id

-- digests 显示摘要信息

--no-trunc 完整信息

###  搜索

docker search < 镜像名>

-- no-trunc 

-s ： 收藏数 不小于指定值



##### 列出正在运行的容器 

docker ps

![image-20191219101217382](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5C%E6%9C%8D%E5%8A%A1%E5%99%A8%5CDocker%E5%85%A5%E9%97%A8.assets%5Cimage-20191219101217382.png)

##### 进入 该容器 内部：

docker exec -it 0180c70c4c94  /bin/bash

![image-20191219101226087](D:%5CgitHub%5Cessay%5C%E7%AC%94%E8%AE%B0%5C%E6%9C%8D%E5%8A%A1%E5%99%A8%5CDocker%E5%85%A5%E9%97%A8.assets%5Cimage-20191219101226087.png)

-it :   等待容器内执行程序完成 ？

退出该容器：

关闭容器退出：exit

不关闭容器： ctrl + P + Q







以当前容器 生成一个新的镜像：

docker commit -m "commit msg" -a "auth"  4a471223bfc4(为当前容器的id)  < image name>





### 删除

docker rmi  < 名字/id> 

单个删除： docker rmi -f  < id>

百度吧。















## 1安装Docker

首先我们需要安装GCC相关的环境：

```
// 安装GCC相关的环境yum -y install gccyum -y install gcc-c++
```

如果曾经安装过Docker(旧版本)的话，得先卸载，如果没有安装过，跳过这一步：

```
// 卸载旧Docker版本yum -y remove docker docker-common docker-selinux docker-engine
```

安装Docker需要的依赖软件包：

```
// 安装Docker需要的依赖软件包：yum install -y yum-utils device-mapper-persistent-data lvm2
```

设置stable镜像仓库(**注意**：我们这里使用国内的镜像地址【因为Docker 官网给出的地址在国外，太慢了！】)

```
// 设置stable镜像仓库：yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```

更新yum软件包索引：

```
// 更新yum软件包索引：yum makecache fast
```

安装DOCKER CE(注意：Docker分为CE版和EE版，一般我们用CE版就够用了)

```
// 安装DOCKER CE：yum -y install docker-ce
```

启动Docker

```
// 启动Dockersystemctl start docker
```

## 2HelloWorld

docker run hello-world

