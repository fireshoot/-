https://blog.csdn.net/u013214212/article/details/81540840

python路径：/usr/local/python3.7/Python-3.7.0

`# vim /usr/bin/pip`
将第一行`#!/usr/bin/python3.4`改为 `#!/usr/bin/python3.6` （即改为/usr/bin/目录下你使用的python版本执行文件）



# 不要删除原有的python2.7 

这导致 yum 不可用 我要吐了。

挽救 办法: [很麻烦](https://www.cnblogs.com/ilovepython/p/11068844.html)

