### 安装：

参考：https://www.cnblogs.com/wangshen31/p/9556804.html

yum 安装，

1.修改获得的临时密码需要修改数据库密码鉴别等级，（鉴别等级高密码需要 大小字符写加数字加符号）

2.开放3306端口， 服务器管理平台也记得配置开放3306端口

### 常用命令

```
重启：systemctl restart mysqld.service

停止：systemctl stop mysqld.service

查看状态：systemctl status mysqld.service

登录：mysql -u root -p
```



