  WebSocket 是发送和接收消息的 底层API，而SockJS 是在 WebSocket 之上的 API；最后 STOMP（面向消息的简单文本协议）是基于 SockJS 的高级API 

​	http是请求- 响应形式 服务器不能主动向客户端推送东西，必须有客户端请求了。

​	webSocket 能建立长连接， 服务器能主动向客户端推送东西。

 ### STOMP

—— Simple Text Oriented Message Protocol——面向消息的简单文本协议 

websocket的上层协议。 面向简单文本。





### 建立连接

![1575268175764](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1575268175764.png)

js:

![1575268190433](C:\Users\mengpeng\AppData\Roaming\Typora\typora-user-images\1575268190433.png)

